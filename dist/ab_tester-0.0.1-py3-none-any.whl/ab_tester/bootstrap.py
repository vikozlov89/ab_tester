import numpy as np
import pandas as pd
from datetime import datetime, date

"""
This module includes bootstrapping functions
"""


class BasicSimulator(object):

    def __init__(self, boot_func, adjust_bias=True, adjust_variance=True):
        self.boot_func = boot_func
        self.adjust_bias = adjust_bias
        self.adjust_variance = adjust_variance

    def boot(self, sample, *args, **kwargs):
        pass

    def randomize_sample(self, sample):
        return np.random.choice(sample, sample.shape[0], replace=False)

    def calculate_bias(self, sample, simulation_result):
        return np.abs(simulation_result.mean() - sample.mean())


class JacknifeSimulator(BasicSimulator):

    def get_next_window(self, sample, i_start, i_end):
        return sample[i_start:i_end], i_start + 1, i_end + 1

    def calculate_number_of_steps(self, sample_size, batch_size):
        return sample_size - batch_size + 1

    def boot(self, sample, batch_size=100):
        res = []
        tmp = self.randomize_sample(sample)
        i_start = 0
        i_end = i_start + batch_size
        n_steps = self.calculate_number_of_steps(tmp.shape[0], batch_size)
        for i in range(n_steps):
            batch, i_start, i_end = self.get_next_window(tmp, i_start, i_end)
            res.append(self.boot_func(batch))
        res = np.array(res)
        return res, self.calculate_bias(sample, res)


class BatchesSimulator(BasicSimulator):

    def get_batches(self, sample, batch_size=100):
        num_batches = sample.shape[0] // batch_size
        return sample[:num_batches * batch_size].reshape((num_batches, batch_size))

    def boot(self, sample, batch_size=100):
        tmp = self.randomize_sample(sample)
        butches = self.get_batches(tmp, batch_size)
        res = self.boot_func(butches, axis=1)
        return res, self.calculate_bias(sample, res)


class BootstrapSimulator(BasicSimulator):

    def boot(self, sample, n_boots=10_000, sample_size = None):
        res = np.zeros(n_boots)
        idmax = sample.shape[0]
        sample_size = idmax if not sample_size else sample_size
        for i in range(n_boots):
            res[i] = self.boot_func(sample[np.random.randint(0, idmax, sample_size)])
        return res, self.calculate_bias(sample, res)


class StratifiedBootstrap(BasicSimulator):

    def construct_query(self, index_names, index_values):

        query = ""
        i = 0
        for n, v in zip(index_names, index_values):
            if isinstance(v, str):
                query += (" and " if i else "") + f"{n} == '{v}' "
            elif isinstance(v, datetime):
                query += (" and " if i else "") + f"{n} == '{v}' "
            elif isinstance(v, date):
                query += (" and " if i else "") + f"{n} == '{v}' "
            else:
                query += (" and " if i else "") + f"{n} == {v} "
            i += 1

        return query

    def pack_to_list(self, to_pack):
        try:
            res = list(to_pack)
        except:
            res = [to_pack]
        return res

    def make_stratified_random_sample(self, sample, structure_to_copy):
        cnames = structure_to_copy.index.names
        res = pd.DataFrame([])
        for vals in structure_to_copy.index:
            clevels = self.pack_to_list(vals)
            cnames = self.pack_to_list(cnames)
            n = structure_to_copy[tuple(clevels) if len(clevels) > 1 else clevels[0]]
            query = self.construct_query(cnames, clevels)
            tmp = sample.query(query)
            if not tmp.shape[0]:
                continue
            resampled_index = np.random.choice(tmp.index, size=n, replace=True)
            res = pd.concat((res, tmp.loc[resampled_index, :].copy()))
        return res.copy()

    def boot(self, sample, column_to_boot, structure_to_copy, n_boots=10_000, resample_freq=1):
        if resample_freq <= 0:
            raise Exception("resample_freq must be a positive number")
        res = []
        tmp = None
        from_last_resample = 1
        resamples_made = 0
        for i in range(n_boots):
            if not i:
                tmp = self.make_stratified_random_sample(sample, structure_to_copy)
                resamples_made += 1
            if from_last_resample > resample_freq * resamples_made:
                resamples_made += 1
                tmp = self.make_stratified_random_sample(sample, structure_to_copy)
            if resample_freq > 1:
                ch = np.random.choice(tmp[column_to_boot].values, size=tmp.shape[0], replace=True)
            else:
                ch = tmp[column_to_boot].values
            res.append(self.boot_func(ch))
            from_last_resample += 1
        res = np.array(res)
        return res, self.calculate_bias(sample, res)


class ParametricSimulator(BasicSimulator):

    def boot(self, sample, distribution_generator, distr_params: dict, n_boots: int = 10_000):
        res = np.zeros(n_boots)
        size = sample.shape[0]
        for i in range(n_boots):
            res[i] = self.boot_func(distribution_generator(size=size, **distr_params))
        return res, self.calculate_bias(sample, res)

def bootstrap_samples_difference(sample1, sample2, boot_func, n_boots=10_000):
    boot_sample_size = min(sample1.shape[0], sample2.shape[0])
    simulator = BootstrapSimulator(boot_func)
    sim_sample1, bias1 = simulator.boot(sample1, n_boots=n_boots, sample_size=boot_sample_size)
    sim_sample2, bias2 = simulator.boot(sample2, n_boots=n_boots, sample_size=boot_sample_size)
    diff = sim_sample1 - sim_sample2
    return dict(sim_sample1=sim_sample1, sim_sample2=sim_sample2, diff=diff, bias1=bias1, bias2=bias2)

def get_resampling_structure(sample1, sample2, group_by, boot_variable):
    s1_struct = sample1.groupby(group_by)[[boot_variable]].count()
    s2_struct = sample2.groupby(group_by)[[boot_variable]].count()
    tmp = pd.merge(left=s1_struct,right=s2_struct,left_index=True,right_index=True,how='inner')
    return tmp.sum(axis=1).apply(lambda x: x //2)


def bootstrap_stratified_samples_difference(sample1, sample2, group_by, boot_variable
                                            , boot_func, n_boots=10_000, resample_freq=1):
    simulator = StratifiedBootstrap(boot_func)
    struct = get_resampling_structure(sample1, sample2, group_by, boot_variable)
    sim_sample1, bias1 = simulator.boot(sample1
                                        , column_to_boot = boot_variable
                                        , structure_to_copy = struct
                                        , n_boots=n_boots
                                        , resample_freq=resample_freq)
    sim_sample2, bias2 = simulator.boot(sample1
                                        , column_to_boot=boot_variable
                                        , structure_to_copy=struct
                                        , n_boots=n_boots
                                        , resample_freq=resample_freq)
    diff = sim_sample1 - sim_sample2
    return dict(sim_sample1=sim_sample1, sim_sample2=sim_sample2, diff=diff)


if __name__ == '__main__':
    from matplotlib import pyplot as plt


